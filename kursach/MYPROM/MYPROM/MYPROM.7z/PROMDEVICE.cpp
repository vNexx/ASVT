//------- MTDEVICE.CPP ---------------------------------------------------------------
#include "stdafx.h"
#include "PROMDEVICE.h" //- ������������ ���� ��� ���������� ������ ����� ������.
//------------------------------------------------------------------------------------


//--- DEVICE::isdigital --------------------------------------------------------------
INT PROMDEVICE::isdigital(CHAR *pinname)
{
	return 1;
}

//--- DEVICE::setup ------------------------------------------------------------------
VOID PROMDEVICE::setup(IINSTANCE *instance, IDSIMCKT *dsimckt)
{
	inst = instance;
	ckt = dsimckt;

	Pin1 = inst->getdsimpin("A0", true);
	Pin2 = inst->getdsimpin("A1", true);
	Pin3 = inst->getdsimpin("A2", true);
	Pin4 = inst->getdsimpin("A3", true);
	Pin5 = inst->getdsimpin("A4", true);
	Pin6 = inst->getdsimpin("A5", true);

	Pin7 = inst->getdsimpin("OE", true);

	Pin8 = inst->getdsimpin("D0", true);
	Pin9 = inst->getdsimpin("D1", true);
	Pin10 = inst->getdsimpin("D2", true);
	Pin11 = inst->getdsimpin("D3", true);
	Pin12 = inst->getdsimpin("D4", true);
	Pin13 = inst->getdsimpin("D5", true);
	Pin14 = inst->getdsimpin("D6", true);
	Pin15 = inst->getdsimpin("D7", true);
	Pin16 = inst->getdsimpin("D8", true);
	Pin17 = inst->getdsimpin("D9", true);
	Pin18 = inst->getdsimpin("D10", true);
	Pin19 = inst->getdsimpin("D11", true);
	Pin20 = inst->getdsimpin("D12", true);
	Pin21 = inst->getdsimpin("D13", true);
	Pin22 = inst->getdsimpin("D14", true);
	Pin23 = inst->getdsimpin("D15", true);
	Pin24 = inst->getdsimpin("D16", true);
	Pin25 = inst->getdsimpin("D17", true);
	Pin26 = inst->getdsimpin("D18", true);
	Pin27 = inst->getdsimpin("D19", true);
	Pin28 = inst->getdsimpin("D20", true);
	Pin29 = inst->getdsimpin("D21", true);
	Pin30 = inst->getdsimpin("D22", true);
	Pin31 = inst->getdsimpin("D23", true);
	Pin32 = inst->getdsimpin("D24", true);
	Pin33 = inst->getdsimpin("D25", true);
	Pin34 = inst->getdsimpin("D26", true);
	Pin35 = inst->getdsimpin("D27", true);
	Pin36 = inst->getdsimpin("D28", true);
	Pin37 = inst->getdsimpin("D29", true);
	Pin38 = inst->getdsimpin("D30", true);
	Pin39 = inst->getdsimpin("D31", true);

	int data[64][32] = { 
		{0, 0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 1,   1, 0, 0, 0,   1, 1, 1, 0}, 
		{0, 0, 0, 0, 0,   0, 0, 0, 1,   0, 0, 1, 1,   1, 0, 0, 0,   1, 1, 1, 0},
		{0, 0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,   0, 1, 1, 0},
		{1, 0, 1, 1,    0, 0, 1, 1, 0},
		{0, 0, 0, 0, 0,   0, 0, 0, 1,   0, 0, 0, 0,   0, 0, 0, 0,   0, 1, 1, 0},
		{1, 0, 1, 0,    1, 0, 0, 1, 1},
		{0, 0, 0, 0, 0,   0, 0, 0, 0,   1, 0, 0, 0,   0, 1, 0, 0,   1, 0, 1, 0},
		{1, 0, 1, 0,    0, 1, 1, 0, 1},
		{0, 0, 0, 0, 0,   0, 0, 0, 0,   1, 1, 1, 1,   1, 1, 1, 0,   1, 0, 1, 0},
		{0, 0, 0, 0, 1,   0, 0, 0, 1,   1, 1, 1, 1,   1, 1, 1, 0,   1, 0, 1, 0},
		{0, 0, 0, 0, 0,   0, 0, 0, 1,   0, 0, 0, 0,   1, 0, 0, 0,   0, 1, 1, 1},
		{1, 0, 1, 1,    0, 1, 1, 0, 1},
		{0, 0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,   1, 0, 0, 0,   0, 1, 1, 1},
		{0, 0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,   0, 1, 1, 0},
		{1, 0, 1, 1,    1, 0, 1, 0, 1},
		{0, 0, 0, 0, 1,   0, 0, 0, 1,   0, 1, 1, 1,   1, 0, 0, 1,   1, 0, 1, 1},
		{1, 1, 0, 0,    1, 0, 0, 1, 1},
		{0, 0, 0, 0, 0,   0, 0, 0, 1,   0, 0, 0, 0,   0, 0, 0, 0,   0, 1, 1, 0},
		{1, 0, 1, 1,    1, 0, 1, 0, 1},
		{0, 0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 1, 1,   0, 0, 0, 0,   1, 1, 1, 0},
		{1, 1, 1, 0,    1, 0, 0, 1, 1},
		{0, 0, 0, 0, 0,   0, 0, 0, 0,   1, 1, 0, 0,   0, 0, 0, 0,   1, 1, 1, 0},
		{1, 1, 1, 0,    1, 0, 1, 0, 1}
	};

	for (int i = 0; i < 64; i++) {
		for (int j = 0; j < 32; j++) {
			ROM[i][j] = data[i][j];			
		}
	}	

	Pin8->setstate(TO_STATE(ROM[0][0]));
	Pin9->setstate(TO_STATE(ROM[0][1]));
	Pin10->setstate(TO_STATE(ROM[0][2]));
	Pin11->setstate(TO_STATE(ROM[0][3]));
	Pin12->setstate(TO_STATE(ROM[0][4]));
	Pin13->setstate(TO_STATE(ROM[0][5]));
	Pin14->setstate(TO_STATE(ROM[0][6]));
	Pin15->setstate(TO_STATE(ROM[0][7]));
	Pin16->setstate(TO_STATE(ROM[0][8]));
	Pin17->setstate(TO_STATE(ROM[0][9]));
	Pin18->setstate(TO_STATE(ROM[0][10]));
	Pin19->setstate(TO_STATE(ROM[0][11]));
	Pin20->setstate(TO_STATE(ROM[0][12]));
	Pin21->setstate(TO_STATE(ROM[0][13]));
	Pin22->setstate(TO_STATE(ROM[0][14]));
	Pin23->setstate(TO_STATE(ROM[0][15]));
	Pin24->setstate(TO_STATE(ROM[0][16]));
	Pin25->setstate(TO_STATE(ROM[0][17]));
	Pin26->setstate(TO_STATE(ROM[0][18]));
	Pin27->setstate(TO_STATE(ROM[0][19]));
	Pin28->setstate(TO_STATE(ROM[0][20]));
	Pin29->setstate(TO_STATE(ROM[0][21]));
	Pin30->setstate(TO_STATE(ROM[0][22]));
	Pin31->setstate(TO_STATE(ROM[0][23]));
	Pin32->setstate(TO_STATE(ROM[0][24]));
	Pin33->setstate(TO_STATE(ROM[0][25]));
	Pin34->setstate(TO_STATE(ROM[0][26]));
	Pin35->setstate(TO_STATE(ROM[0][27]));
	Pin36->setstate(TO_STATE(ROM[0][28]));
	Pin37->setstate(TO_STATE(ROM[0][29]));
	Pin38->setstate(TO_STATE(ROM[0][30]));
	Pin39->setstate(TO_STATE(ROM[0][31]));
}

//---- DEVICE::runctrl ------------------------------------------------------------------
VOID PROMDEVICE::runctrl(RUNMODES mode)
{

}

//---- DEVICE::actuate ------------------------------------------------------------------
VOID PROMDEVICE::actuate(REALTIME time, ACTIVESTATE newstate)
{
	//---- ������������� ��������� (ACTIVESTATE newstate)
}

//---- DEVICE::indicate ------------------------------------------------------------------
BOOL PROMDEVICE::indicate(REALTIME time, ACTIVEDATA *data)
{
	return FALSE;
}

//---- DEVICE::simulate ------------------------------------------------------------------
VOID PROMDEVICE::simulate(ABSTIME time, DSIMMODES mode)
{
	if (ishigh(Pin7->istate())) {
		UINT ADDR = TO_UINT(Pin6, Pin5, Pin4, Pin3, Pin2, Pin1);
		Pin8->setstate(time, DELAY__, TO_STATE(ROM[ADDR][0]));
		Pin9->setstate(time, DELAY__, TO_STATE(ROM[ADDR][1]));
		Pin10->setstate(time, DELAY__, TO_STATE(ROM[ADDR][2]));
		Pin11->setstate(time, DELAY__, TO_STATE(ROM[ADDR][3]));
		Pin12->setstate(time, DELAY__, TO_STATE(ROM[ADDR][4]));
		Pin13->setstate(time, DELAY__, TO_STATE(ROM[ADDR][5]));
		Pin14->setstate(time, DELAY__, TO_STATE(ROM[ADDR][6]));
		Pin15->setstate(time, DELAY__, TO_STATE(ROM[ADDR][7]));
		Pin16->setstate(time, DELAY__, TO_STATE(ROM[ADDR][8]));
		Pin17->setstate(time, DELAY__, TO_STATE(ROM[ADDR][9]));
		Pin18->setstate(time, DELAY__, TO_STATE(ROM[ADDR][10]));
		Pin19->setstate(time, DELAY__, TO_STATE(ROM[ADDR][11]));
		Pin20->setstate(time, DELAY__, TO_STATE(ROM[ADDR][12]));
		Pin21->setstate(time, DELAY__, TO_STATE(ROM[ADDR][13]));
		Pin22->setstate(time, DELAY__, TO_STATE(ROM[ADDR][14]));
		Pin23->setstate(time, DELAY__, TO_STATE(ROM[ADDR][15]));
		Pin24->setstate(time, DELAY__, TO_STATE(ROM[ADDR][16]));
		Pin25->setstate(time, DELAY__, TO_STATE(ROM[ADDR][17]));
		Pin26->setstate(time, DELAY__, TO_STATE(ROM[ADDR][18]));
		Pin27->setstate(time, DELAY__, TO_STATE(ROM[ADDR][19]));
		Pin28->setstate(time, DELAY__, TO_STATE(ROM[ADDR][20]));
		Pin29->setstate(time, DELAY__, TO_STATE(ROM[ADDR][21]));
		Pin30->setstate(time, DELAY__, TO_STATE(ROM[ADDR][22]));
		Pin31->setstate(time, DELAY__, TO_STATE(ROM[ADDR][23]));
		Pin32->setstate(time, DELAY__, TO_STATE(ROM[ADDR][24]));
		Pin33->setstate(time, DELAY__, TO_STATE(ROM[ADDR][25]));
		Pin34->setstate(time, DELAY__, TO_STATE(ROM[ADDR][26]));
		Pin35->setstate(time, DELAY__, TO_STATE(ROM[ADDR][27]));
		Pin36->setstate(time, DELAY__, TO_STATE(ROM[ADDR][28]));
		Pin37->setstate(time, DELAY__, TO_STATE(ROM[ADDR][29]));
		Pin38->setstate(time, DELAY__, TO_STATE(ROM[ADDR][30]));
		Pin39->setstate(time, DELAY__, TO_STATE(ROM[ADDR][31]));
	}
}

//---- DEVICE::callback ------------------------------------------------------------------
VOID PROMDEVICE::callback(ABSTIME time, EVENTID eventid)
{

}

UINT PROMDEVICE::TO_UINT(IDSIMPIN * p32, IDSIMPIN * p16, IDSIMPIN * p8, IDSIMPIN * p4, IDSIMPIN * p2, IDSIMPIN * p1)
{
	UINT res = 0U;
	if (ishigh(p32->istate())) {
		res += 32U;
	}
	if (ishigh(p16->istate())) {
		res += 16U;
	}
	if (ishigh(p8->istate())) {
		res += 8U;
	}
	if (ishigh(p4->istate())) {
		res += 4U;
	}
	if (ishigh(p2->istate())) {
		res += 2U;
	}
	if (ishigh(p1->istate())) {
		res += 1U;
	}
	return res;
}

STATE PROMDEVICE::TO_STATE(UINT value)
{
	return (value > 0) ? STATE::SHI : STATE::SLO;
}


