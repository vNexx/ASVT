//----- ������������ ���� MTDEVICE.h ------------------------------------
#pragma once
#include "vsm.h"

class PROMDEVICE : public IDSIMMODEL
{
public:
	INT isdigital(CHAR *pinname);
	VOID setup(IINSTANCE *inst, IDSIMCKT *dsim);
	VOID runctrl(RUNMODES mode);
	VOID actuate(REALTIME time, ACTIVESTATE newstate);
	BOOL indicate(REALTIME time, ACTIVEDATA *data);
	VOID simulate(ABSTIME time, DSIMMODES mode);
	VOID callback(ABSTIME time, EVENTID eventid);
private:
	const UINT DELAY__ = 80000;
	IINSTANCE *inst;
	IDSIMCKT *ckt;
	// A
	IDSIMPIN *Pin1; //A0
	IDSIMPIN *Pin2; //A1
	IDSIMPIN *Pin3; //A2
	IDSIMPIN *Pin4; //A3
	IDSIMPIN *Pin5; //A4
	IDSIMPIN *Pin6; //A5

	IDSIMPIN *Pin7; //OE
	// D
	IDSIMPIN *Pin8; //D0
	IDSIMPIN *Pin9; //D1
	IDSIMPIN *Pin10; //D2
	IDSIMPIN *Pin11; //D3
	IDSIMPIN *Pin12; //D4					 
	IDSIMPIN *Pin13; //D5
	IDSIMPIN *Pin14; //D6
	IDSIMPIN *Pin15; //D7
	IDSIMPIN *Pin16; //D8
	IDSIMPIN *Pin17; //D9
	IDSIMPIN *Pin18; //D10
	IDSIMPIN *Pin19; //D11
	IDSIMPIN *Pin20; //D12
	IDSIMPIN *Pin21; //D13
	IDSIMPIN *Pin22; //D14
	IDSIMPIN *Pin23; //D15
	IDSIMPIN *Pin24; //D16
	IDSIMPIN *Pin25; //D17
	IDSIMPIN *Pin26; //D18
	IDSIMPIN *Pin27; //D19
	IDSIMPIN *Pin28; //D20					 
	IDSIMPIN *Pin29; //D21
	IDSIMPIN *Pin30; //D22
	IDSIMPIN *Pin31; //D23
	IDSIMPIN *Pin32; //D24
	IDSIMPIN *Pin33; //D25
	IDSIMPIN *Pin34; //D26
	IDSIMPIN *Pin35; //D27
	IDSIMPIN *Pin36; //D28
	IDSIMPIN *Pin37; //D29
	IDSIMPIN *Pin38; //D30
	IDSIMPIN *Pin39; //D31

	UINT ROM[64][32];

	UINT TO_UINT(IDSIMPIN * p32, IDSIMPIN * p16, IDSIMPIN * p8, IDSIMPIN *p4, IDSIMPIN *p2, IDSIMPIN *p1);
	STATE TO_STATE(UINT value);
};
